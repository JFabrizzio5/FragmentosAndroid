package com.example.listitafrag;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class BaseDeActividades extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_de_actividades);

// Cargar el fragmento fragdato1 en el primer FrameLayout
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragdato1 fragDato1Fragment = new fragdato1();
        fragmentTransaction.replace(R.id.frameLayout1, fragDato1Fragment);
        fragmentTransaction.commit();
// Cargar el fragmento fragresultado1 en el segundo FrameLayout
        FragmentManager fragmentManager2 = getSupportFragmentManager(); // Cambiado a fragmentManager2
        FragmentTransaction fragmentTransaction2 = fragmentManager2.beginTransaction(); // Cambiado a fragmentTransaction2
        fragresultado1 fragResultado1Fragment = new fragresultado1();
        fragmentTransaction2.replace(R.id.frameLayout2, fragResultado1Fragment); // Cambiado a fragmentTransaction2
        fragmentTransaction2.commit(); // Cambiado a fragmentTransaction2


    }
}
