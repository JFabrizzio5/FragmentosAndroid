package com.example.listitafrag;

public class Clasesita {
    private int datito;
    public int getDatito() {
        return datito;
    }

    public void setDatito(int datito) {
        this.datito = datito;
    }

    int doble(){
        return datito * 2;
    }

    int triple(){
        return datito * 3;
    }

    int cuadruple(){
        return datito * 4;
    }
}
